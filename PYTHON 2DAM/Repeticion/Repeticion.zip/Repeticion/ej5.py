num=int(input("Introduce un numero: "))
i=1
cuadrado=0
for i in range(i,num):
    cuadrado=i**2
    print(cuadrado)

