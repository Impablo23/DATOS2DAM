num=int(input("Introduce su numero"))
factorial=1
i=1
while i<=num:
    factorial=factorial*i
    i+=1

print("Su factorial es:",factorial)