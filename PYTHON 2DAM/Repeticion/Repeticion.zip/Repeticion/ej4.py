num=int(input("Introduce un numero:"))
i=1
for i in range(i,num+1,1):
    print("*"*i)
