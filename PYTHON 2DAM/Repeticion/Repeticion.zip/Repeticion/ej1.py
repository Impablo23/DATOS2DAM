algo= input("Escribe algo:")
for i in algo:
    print(i)
    
