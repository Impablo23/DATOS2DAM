num=0
while num%2==0:
    num=int(input("INtroduce un numero impar: "))

i=1
for i in range(i,num+1,2):
    print("*"*i)