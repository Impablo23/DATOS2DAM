import random

n=random.randint(0,1)

print ("numero es ",n)

exit (n)