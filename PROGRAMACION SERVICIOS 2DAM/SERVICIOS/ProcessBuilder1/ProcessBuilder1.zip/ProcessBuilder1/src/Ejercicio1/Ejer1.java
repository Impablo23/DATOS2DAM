package Ejercicio1;
//PABLO RICO MACHIO 2DAM PROCESOS
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Ejer1 {
	public static void main(String[] args) throws IOException, InterruptedException {

		Scanner input= new Scanner(System.in);
		String arg="notepad.exe";
		String note="nombres.txt";
		String chrome="C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\chrome.exe";
		String ies="https://iesplayamar.es/";
		//No te puedo ponder la captura porque tengo una version diferente
		try {
			ProcessBuilder bloc = new ProcessBuilder(arg,note);
			Process uno = bloc.start();
			Thread.sleep(5000);
			System.out.println("HHH");
			
			ProcessBuilder web = new ProcessBuilder(chrome,ies);
			Process dos=web.start();
		}catch (Exception e){
			e.getStackTrace();
		}
		 
		 
	}
}