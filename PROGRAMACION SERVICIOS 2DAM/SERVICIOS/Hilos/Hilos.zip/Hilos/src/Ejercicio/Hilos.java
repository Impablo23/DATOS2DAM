package Ejercicio;

public class Hilos extends Thread{
	
	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		
		
		Raton uno= new Raton("Nico",3);
		Raton dos= new Raton("Ivan",2);
		Raton tres= new Raton("Pablo",1);
		Raton cuatro= new Raton("Antonio",4);
		
		uno.start();
		dos.start();
		tres.start();
		cuatro.start();
		

	}

}
