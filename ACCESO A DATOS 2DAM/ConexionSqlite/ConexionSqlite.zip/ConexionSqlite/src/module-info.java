/**
 * 
 */
/**
 * 
 */
module ConexionSqlite {
	requires java.sql;
}