/**
 * 
 */
/**
 * 
 */
module RicoPabloExamen1 {
	requires java.sql;
}