/**
 * 
 */
/**
 * 
 */
module TransaccionesSQLITE {
	requires java.sql;
}