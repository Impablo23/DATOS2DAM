/**
 * 
 */
/**
 * @author pablo
 *
 */
module FicheroConfig {
}