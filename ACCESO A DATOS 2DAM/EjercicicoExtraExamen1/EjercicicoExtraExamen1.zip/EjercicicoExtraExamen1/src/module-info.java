/**
 * 
 */
/**
 * 
 */
module EjercicicoExtraExamen1 {
	requires java.sql;
	requires mysql.connector.j;
}