/**
 * 
 */
/**
 * 
 */
module FicheroDom {
	requires java.xml;
}