/**
 * 
 */
/**
 * 
 */
module FicheroBInario {
}